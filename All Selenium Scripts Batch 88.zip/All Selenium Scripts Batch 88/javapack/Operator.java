package javapack;

public class Operator {

	public static void main(String[] args) {
		int x=2,y=3,z=4;
		int n=(x+y)*z;
		System.out.println(n);

	}

}
