package javapack;

public class Sample {
	
	static int x=10;
	static final int y=30;

	public static void main(String[] args) {
		
		System.out.println("Welcome to Java");
		x=20;
		System.out.println(x);
		System.out.println("Y:"+y);
		

	}

}
