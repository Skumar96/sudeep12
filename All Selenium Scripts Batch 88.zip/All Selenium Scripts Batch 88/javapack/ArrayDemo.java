package javapack;

public class ArrayDemo {

	public static void main(String[] args) {
		
		int a1[]= {1,2,3,4};
		System.out.println("2nd element in array:"+a1[1]);
		int a2[]=new int[4];
		a2[0]=10;
		a2[1]=20;
		a2[2]=30;
		a2[3]=40;
		System.out.println("4th eleement in array:"+a2[3]);

	}

}
